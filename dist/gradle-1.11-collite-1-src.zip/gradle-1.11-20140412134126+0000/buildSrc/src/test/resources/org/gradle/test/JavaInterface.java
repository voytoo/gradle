package org.gradle.test;

public interface JavaInterface extends Interface1, Interface2 {
}
