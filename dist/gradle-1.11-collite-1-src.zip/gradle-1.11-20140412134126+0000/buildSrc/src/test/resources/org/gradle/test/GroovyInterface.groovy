package org.gradle.test

public interface GroovyInterface extends Interface1, Interface2 {
}