package webinar;

public interface Demoable {
  String getDescription();
}