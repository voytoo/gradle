import org.testng.annotations.Test;

public class FooTest {
  @Test public void test() {
    assert false: "test failure";
  }
}