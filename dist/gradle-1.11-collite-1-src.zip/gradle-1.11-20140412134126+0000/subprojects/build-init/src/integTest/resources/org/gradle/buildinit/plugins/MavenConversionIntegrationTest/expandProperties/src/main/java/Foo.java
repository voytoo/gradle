import org.apache.commons.collections.map.MultiValueMap;

public class Foo {

  MultiValueMap mvp = new MultiValueMap();

  public String toString() {
    return "foo";
  }
}