import org.junit.Test;
import static junit.framework.Assert.assertFalse;

public class FooTest {

  @Test
  public void test() {
    assertFalse(false);
  }
}