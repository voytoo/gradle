package org.gradle;

public class SourceBuildOnly {}