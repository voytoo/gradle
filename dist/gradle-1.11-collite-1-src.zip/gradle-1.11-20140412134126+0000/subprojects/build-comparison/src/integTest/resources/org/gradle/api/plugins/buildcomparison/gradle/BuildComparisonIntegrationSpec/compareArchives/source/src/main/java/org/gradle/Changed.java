package org.gradle;

public class Changed {
    private String field1;
    private int field2;

    public void method1() {}
}